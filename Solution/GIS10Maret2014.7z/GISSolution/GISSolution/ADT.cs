﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GIS
{
    class ADT
    {
    }

    public class MySession
    {
        private static string _userID = "";

        public static string UserID
        {
            get { return MySession._userID; }
            set { MySession._userID = value; }
        }        
    }

    public class FormPosition
    {
        private static int _xStartPos = 0;

        public static int XStartPos
        {
            get { return FormPosition._xStartPos; }
            set { FormPosition._xStartPos = value; }
        }

        private static int _yStartPos = 0;

        public static int YStartPos
        {
            get { return FormPosition._yStartPos; }
            set { FormPosition._yStartPos = value; }
        }
    }
}