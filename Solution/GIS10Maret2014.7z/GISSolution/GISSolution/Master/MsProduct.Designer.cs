﻿namespace GIS.Master
{
    partial class MsProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.cmbSign = new System.Windows.Forms.ComboBox();
            this.hidProdID = new System.Windows.Forms.Label();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSellPrice = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProdName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPrevQty = new System.Windows.Forms.TextBox();
            this.cmbClass = new System.Windows.Forms.ComboBox();
            this.cbRetur = new System.Windows.Forms.CheckBox();
            this.hidPrevQtyCPrice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(160, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 56;
            this.label4.Text = "Rp.";
            // 
            // cmbSign
            // 
            this.cmbSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSign.FormattingEnabled = true;
            this.cmbSign.Location = new System.Drawing.Point(120, 64);
            this.cmbSign.Name = "cmbSign";
            this.cmbSign.Size = new System.Drawing.Size(35, 21);
            this.cmbSign.TabIndex = 2;
            // 
            // hidProdID
            // 
            this.hidProdID.AutoSize = true;
            this.hidProdID.Location = new System.Drawing.Point(13, 250);
            this.hidProdID.Name = "hidProdID";
            this.hidProdID.Size = new System.Drawing.Size(35, 13);
            this.hidProdID.TabIndex = 55;
            this.hidProdID.Text = "label8";
            this.hidProdID.Visible = false;
            // 
            // DataGridView1
            // 
            this.DataGridView1.AllowUserToAddRows = false;
            this.DataGridView1.AllowUserToDeleteRows = false;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView1.Location = new System.Drawing.Point(12, 290);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.ReadOnly = true;
            this.DataGridView1.Size = new System.Drawing.Size(770, 324);
            this.DataGridView1.StandardTab = true;
            this.DataGridView1.TabIndex = 11;
            this.DataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellClick);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(400, 241);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(300, 241);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 9;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(195, 241);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(400, 12);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(382, 207);
            this.txtNote.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(364, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 54;
            this.label5.Text = "Note";
            // 
            // txtSellPrice
            // 
            this.txtSellPrice.Location = new System.Drawing.Point(190, 91);
            this.txtSellPrice.Name = "txtSellPrice";
            this.txtSellPrice.Size = new System.Drawing.Size(136, 20);
            this.txtSellPrice.TabIndex = 6;
            this.txtSellPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSellPrice_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 53;
            this.label3.Text = "Sell Price";
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(161, 64);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(109, 20);
            this.txtQty.TabIndex = 3;
            this.txtQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQty_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 52;
            this.label2.Text = "Adjustment Quantity";
            // 
            // txtProdName
            // 
            this.txtProdName.BackColor = System.Drawing.SystemColors.Window;
            this.txtProdName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtProdName.Location = new System.Drawing.Point(120, 12);
            this.txtProdName.Name = "txtProdName";
            this.txtProdName.Size = new System.Drawing.Size(206, 20);
            this.txtProdName.TabIndex = 0;
            this.txtProdName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProdName_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 51;
            this.label1.Text = "Product Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 57;
            this.label6.Text = "Previous Quantity";
            // 
            // txtPrevQty
            // 
            this.txtPrevQty.BackColor = System.Drawing.SystemColors.Window;
            this.txtPrevQty.Enabled = false;
            this.txtPrevQty.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPrevQty.Location = new System.Drawing.Point(120, 38);
            this.txtPrevQty.Name = "txtPrevQty";
            this.txtPrevQty.Size = new System.Drawing.Size(206, 20);
            this.txtPrevQty.TabIndex = 1;
            // 
            // cmbClass
            // 
            this.cmbClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbClass.FormattingEnabled = true;
            this.cmbClass.Location = new System.Drawing.Point(120, 91);
            this.cmbClass.Name = "cmbClass";
            this.cmbClass.Size = new System.Drawing.Size(35, 21);
            this.cmbClass.TabIndex = 5;
            this.cmbClass.SelectedIndexChanged += new System.EventHandler(this.cmbClass_SelectedIndexChanged);
            // 
            // cbRetur
            // 
            this.cbRetur.AutoSize = true;
            this.cbRetur.Location = new System.Drawing.Point(276, 66);
            this.cbRetur.Name = "cbRetur";
            this.cbRetur.Size = new System.Drawing.Size(52, 17);
            this.cbRetur.TabIndex = 4;
            this.cbRetur.Text = "Retur";
            this.cbRetur.UseVisualStyleBackColor = true;
            this.cbRetur.Click += new System.EventHandler(this.cbRetur_Click);
            // 
            // hidPrevQtyCPrice
            // 
            this.hidPrevQtyCPrice.AutoSize = true;
            this.hidPrevQtyCPrice.Location = new System.Drawing.Point(54, 250);
            this.hidPrevQtyCPrice.Name = "hidPrevQtyCPrice";
            this.hidPrevQtyCPrice.Size = new System.Drawing.Size(35, 13);
            this.hidPrevQtyCPrice.TabIndex = 59;
            this.hidPrevQtyCPrice.Text = "label7";
            this.hidPrevQtyCPrice.Visible = false;
            // 
            // MsProduct
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(794, 626);
            this.Controls.Add(this.hidPrevQtyCPrice);
            this.Controls.Add(this.cbRetur);
            this.Controls.Add(this.cmbClass);
            this.Controls.Add(this.txtPrevQty);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbSign);
            this.Controls.Add(this.hidProdID);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSellPrice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtProdName);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MsProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "MsProduct";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MsProduct_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbSign;
        private System.Windows.Forms.Label hidProdID;
        internal System.Windows.Forms.DataGridView DataGridView1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.TextBox txtNote;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox txtSellPrice;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtQty;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox txtProdName;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox txtPrevQty;
        private System.Windows.Forms.ComboBox cmbClass;
        private System.Windows.Forms.CheckBox cbRetur;
        private System.Windows.Forms.Label hidPrevQtyCPrice;
    }
}