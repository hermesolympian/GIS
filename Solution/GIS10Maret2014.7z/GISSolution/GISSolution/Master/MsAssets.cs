﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Net.Mail;

namespace GIS.Master
{
    public partial class MsAssets : Form
    {
        string conString;
        List<string> listAssName;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;

        string state;

        public MsAssets()
        {
            InitializeComponent();

            loadDataGrid();
            loadAutoComplete();

            resetForm();
            state = "save";
            configForm();
        }

        private void loadDataGrid()
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                listAssName = new List<string>();
                cmd = new MySqlCommand();
                cmd.CommandText = "select assetsid, assetsname, qty, value, note from msassets";
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                DataRow dr = new DataTable().NewRow();

                dt.Columns.Add(new DataColumn("assetsid", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("Assets Name", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Quantity", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("Value", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Note", Type.GetType("System.String")));

                while (reader.Read())
                {
                    dr = dt.NewRow();
                    dr["assetsid"] = reader.GetInt32(0);
                    dr["Assets Name"] = reader.GetString(1);
                    dr["Quantity"] = reader.GetInt32(2);
                    dr["Value"] = "Rp." + reader.GetDecimal(3).ToString();
                    dr["Note"] = reader.GetString(4);

                    dt.Rows.Add(dr);

                    listAssName.Add(reader.GetString(1));
                }
                DataGridView1.DataSource = dt;

                DataGridView1.Columns["assetsid"].Visible = false;
                DataGridView1.Columns["Note"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void loadAutoComplete()
        {
            string[] assName = new string[listAssName.Count];
            var source = new AutoCompleteStringCollection();
            int i = 0;

            foreach (string temp in listAssName)
            {
                assName[i] = temp;
                i++;
            }
            source.AddRange(assName);

            txtAssName.AutoCompleteCustomSource = source;
            txtAssName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtAssName.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            loadAssets(DataGridView1.CurrentRow.Cells[0].Value.ToString());

            state = "edit";
            configForm();
        }

        private void loadAssets(string assetsid)
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                cmd = new MySqlCommand();
                cmd.CommandText = "select assetsid, assetsname, qty, value, note from msassets where assetsid = " + assetsid;
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    hidAssID.Text = reader.GetInt32(0).ToString();
                    txtAssName.Text = reader.GetString(1);
                    txtQty.Text = reader.GetInt32(2).ToString();
                    txtValue.Text = reader.GetDecimal(3).ToString();
                    txtNote.Text = reader.GetString(4);
                }

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (state == "save")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into msassets (assetsname, qty, value, note, datein, userin) values ('" + txtAssName.Text + "', '" + txtQty.Text + "', " + txtValue.Text.Replace(',', '.') + ", '" + txtNote.Text + "', now(), " + MySession.UserID + ")";
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Save New Assets !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else if (state == "edit")
            {
                state = "update";
                configForm();
            }
            else if (state == "update")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hsassets (assetsname, qty, value, note, datein, userin, dateup, userup) select assetsname, qty, value, note, datein, userin, now(), " + MySession.UserID + " from msassets where assetsid = " + hidAssID.Text + "; update msassets set assetsname = '" + txtAssName.Text + "', qty = '" + txtQty.Text + "', value = " + txtValue.Text.Replace(',', '.') + ", note = '" + txtNote.Text + "' where assetsid = " + hidAssID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Update Assets !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
            state = "save";
            configForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (hidAssID.Text != "")
            {
                if (MessageBox.Show("Are you sure want to delete this item?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hsassets (assetsname, qty, value, note, datein, userin, dateup, userup) select assetsname, qty, value, note, datein, userin, now(), " + MySession.UserID + " from msassets where assetsid = " + hidAssID.Text + "; delete from msassets where assetsid = " + hidAssID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Delete Assets !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No Assets Chosen !!");
            }
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txtAssName.Text))
            {
                MessageBox.Show("Please Fill Assets Name !!");
            }
            else if (string.IsNullOrEmpty(txtQty.Text))
            {
                MessageBox.Show("Please Fill Quantity !!");
            }
            else if (!isNumVCS(txtQty.Text) || (isNumVCS(txtQty.Text) && txtQty.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Quantity With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtValue.Text))
            {
                MessageBox.Show("Please Fill Value !!");
            }
            else if (!isDecimalVCS(txtValue.Text) || (isDecimalVCS(txtQty.Text) && txtQty.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Value With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtNote.Text))
            {
                MessageBox.Show("Please Fill Note !!");
            }
            else
            {
                return true;
            }

            return false;
        }

        private void resetForm()
        {
            txtAssName.Text = "";
            txtQty.Text = "";
            txtValue.Text = "";
            txtNote.Text = "";

            hidAssID.Text = "";
        }

        private void configForm()
        {
            if (state == "save")
            {
                txtAssName.Enabled = true;
                txtQty.Enabled = true;
                txtValue.Enabled = true;
                txtNote.Enabled = true;

                btnSave.Text = "Save";
            }
            else if (state == "edit")
            {
                txtAssName.Enabled = false;
                txtQty.Enabled = false;
                txtValue.Enabled = false;
                txtNote.Enabled = false;

                btnSave.Text = "Edit";
            }
            else if (state == "update")
            {
                txtAssName.Enabled = true;
                txtQty.Enabled = true;
                txtValue.Enabled = true;
                txtNote.Enabled = true;

                btnSave.Text = "Update";
            }
        }

        private bool isNumVCS(string inputNum)
        {
            Int64 dt = 0;
            return Int64.TryParse(inputNum, out dt);
        }

        private bool isDecimalVCS(string inputNum)
        {
            Decimal dt = 0;
            return Decimal.TryParse(inputNum, out dt);
        }

        private void MsAssets_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure want to close this form?", "Warning", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
                this.Activate();
            }
        }

        private void txtAssName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                foreach (DataGridViewRow row in DataGridView1.Rows)
                {
                    if (row.Cells[1].Value.ToString().ToUpper() == txtAssName.Text.ToUpper())
                    {
                        DataGridView1.CurrentCell = DataGridView1[1, row.Index];
                        loadAssets(DataGridView1.CurrentRow.Cells[0].Value.ToString());

                        state = "edit";
                        configForm();
                    }
                }
            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }

        private void txtValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            const char Koma = (char)46;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete && e.KeyChar != Koma;
        }
    }
}
