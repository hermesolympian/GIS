﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Net.Mail;

namespace GIS.Master
{
    public partial class MsPartner : Form
    {
        string conString;
        List<string> listPartName;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;

        string state;
        string mode;

        public MsPartner()
        {
            InitializeComponent();

            rbVendor.Checked = true;
            mode = "vendor";

            loadDataGrid();
            loadAutoComplete();

            resetForm();
            state = "save";
            configForm();
        }

        private void loadDataGrid()
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                listPartName = new List<string>();
                cmd = new MySqlCommand();
                cmd.CommandText = "select partnerid, partnername, phone, mobile, email, address, placeofbirth, dateofbirth from mspartner";

                if (mode == "vendor")
                {
                    cmd.CommandText = cmd.CommandText + " where regional is NULL";
                }
                else if (mode == "staff")
                {
                    cmd.CommandText = cmd.CommandText + " where regional is not NULL";
                }

                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                DataRow dr = new DataTable().NewRow();

                dt.Columns.Add(new DataColumn("partnerid", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("Partner Name", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Phone", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Mobile", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Email", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Address", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Place - Date Of Birth", Type.GetType("System.String")));

                while (reader.Read())
                {
                    dr = dt.NewRow();
                    dr["partnerid"] = reader.GetInt32(0);
                    dr["Partner Name"] = reader.GetString(1);
                    dr["Phone"] = reader.GetString(2);
                    dr["Mobile"] = reader.GetString(3);
                    dr["Email"] = reader.GetString(4);
                    dr["Address"] = reader.GetString(5);
                    dr["Place - Date Of Birth"] = reader.GetString(6) + " - " + reader.GetDateTime(7).ToString("dd MMMM yyyy");

                    dt.Rows.Add(dr);

                    listPartName.Add(reader.GetString(1));
                }
                DataGridView1.DataSource = dt;

                DataGridView1.Columns["partnerid"].Visible = false;
                DataGridView1.Columns["Place - Date Of Birth"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void loadAutoComplete()
        {
            string[] partName = new string[listPartName.Count];
            var source = new AutoCompleteStringCollection();
            int i = 0;

            foreach (string temp in listPartName)
            {
                partName[i] = temp;
                i++;
            }
            source.AddRange(partName);

            txtPartName.AutoCompleteCustomSource = source;
            txtPartName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtPartName.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            loadPartner(DataGridView1.CurrentRow.Cells[0].Value.ToString());

            state = "edit";
            configForm();
        }

        private void loadPartner(string partnerid)
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                cmd = new MySqlCommand();
                cmd.CommandText = "select partnerid, partnername, coalesce(regional,''), phone, mobile, email, address, placeofbirth, dateofbirth from mspartner where partnerid = " + partnerid;
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    hidPartnerID.Text = reader.GetInt32(0).ToString();
                    txtPartName.Text = reader.GetString(1);
                    txtRegional.Text = reader.GetString(2);
                    txtPhone.Text = reader.GetString(3);
                    txtMobile.Text = reader.GetString(4);
                    txtEmail.Text = reader.GetString(5);
                    txtAddress.Text = reader.GetString(6);
                    txtPOB.Text = reader.GetString(7);
                    dtpDOB.Value = reader.GetDateTime(8);
                }

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (state == "save")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        string extra = (mode == "staff") ? "regional, " : "";
                        string extra2 = (mode == "staff") ? "'" + txtRegional.Text + "', " : "";

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into mspartner (partnername, " + extra + "phone, mobile, email, address, dateofbirth, placeofbirth, datein, userin) values ('" + txtPartName.Text + "', " + extra2 + "'" + txtPhone.Text + "', '" + txtMobile.Text + "', '" + txtEmail.Text + "', '" + txtAddress.Text + "', '" + dtpDOB.Value.ToString("yyyy-MM-dd") + "','" + txtPOB.Text + "', now(), " + MySession.UserID + ")";
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Save New Partner !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else if (state == "edit")
            {
                state = "update";
                configForm();
            }
            else if (state == "update")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        string extra = (mode == "staff") ? "regional = '" + txtRegional.Text + "', " : "";

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hspartner (partnername, regional, phone, mobile, email, address, dateofbirth, placeofbirth, datein, userin, dateup, userup) select partnername, regional, phone, mobile, email, address, dateofbirth, placeofbirth, datein, userin, now(), " + MySession.UserID + " from mspartner where partnerid = " + hidPartnerID.Text + "; update mspartner set partnername = '" + txtPartName.Text + "', " + extra + "phone = '" + txtPhone.Text + "', mobile = '" + txtMobile.Text + "', email = '" + txtEmail.Text + "', address = '" + txtAddress.Text + "', placeofbirth = '" + txtPOB.Text + "', dateofbirth = '" + dtpDOB.Value.ToString("yyyy-MM-dd") + "' where partnerid = " + hidPartnerID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Update Partner !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
            state = "save";
            configForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (hidPartnerID.Text != "")
            {
                if (MessageBox.Show("Are you sure want to delete this item?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        string extra = (mode == "staff") ? "regional = " + txtRegional.Text + ", " : "";

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hspartner (partnername, regional, phone, mobile, email, address, dateofbirth, placeofbirth, datein, userin, dateup, userup) select partnername, regional, phone, mobile, email, address, dateofbirth, placeofbirth, datein, userin, now(), " + MySession.UserID + " from mspartner where partnerid = " + hidPartnerID.Text + "; delete from mspartner where partnerid = " + hidPartnerID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Delete Partner !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No Partner Chosen !!");
            }
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txtPartName.Text))
            {
                MessageBox.Show("Please Fill Partner Name !!");
            }
            else if (string.IsNullOrEmpty(txtPhone.Text))
            {
                MessageBox.Show("Please Fill Phone !!");
            }
            else if (!isNumVCS(txtPhone.Text) || (isNumVCS(txtPhone.Text) && txtPhone.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Phone With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtMobile.Text))
            {
                MessageBox.Show("Please Fill Mobile !!");
            }
            else if (!isNumVCS(txtMobile.Text) || (isNumVCS(txtMobile.Text) && txtMobile.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Mobile With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Please Fill Email !!");
            }
            else if (!isValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Please Fill Email With Valid Email !!");
            }
            else if (mode == "staff" && string.IsNullOrEmpty(txtRegional.Text))
            {
                MessageBox.Show("Please Fill Regional !!");
            }
            else if (string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Please Fill Address !!");
            }
            else if (string.IsNullOrEmpty(txtPOB.Text))
            {
                MessageBox.Show("Please Fill Place Of Birth !!");
            }
            else
            {
                return true;
            }

            return false;
        }

        private void resetForm()
        {
            txtPartName.Text = "";
            txtPhone.Text = "";
            txtMobile.Text = "";
            txtEmail.Text = "";
            txtRegional.Text = "";
            txtAddress.Text = "";
            txtPOB.Text = "";
            dtpDOB.Value = DateTime.Now;

            hidPartnerID.Text = "";
        }

        private void configForm()
        {
            if (state == "save")
            {
                rbVendor.Enabled = true;
                rbStaff.Enabled = true;
                txtPartName.Enabled = true;
                txtPhone.Enabled = true;
                txtMobile.Enabled = true;
                txtEmail.Enabled = true;
                txtRegional.Enabled = true;
                txtAddress.Enabled = true;
                txtPOB.Enabled = true;
                dtpDOB.Enabled = true;

                btnSave.Text = "Save";
            }
            else if (state == "edit")
            {
                rbVendor.Enabled = false;
                rbStaff.Enabled = false;
                txtPartName.Enabled = false;
                txtPhone.Enabled = false;
                txtMobile.Enabled = false;
                txtEmail.Enabled = false;
                txtRegional.Enabled = false;
                txtAddress.Enabled = false;
                txtPOB.Enabled = false;
                dtpDOB.Enabled = false;

                btnSave.Text = "Edit";
            }
            else if (state == "update")
            {
                rbVendor.Enabled = false;
                rbStaff.Enabled = false;
                txtPartName.Enabled = true;
                txtPhone.Enabled = true;
                txtMobile.Enabled = true;
                txtEmail.Enabled = true;
                txtRegional.Enabled = true;
                txtAddress.Enabled = true;
                txtPOB.Enabled = true;
                dtpDOB.Enabled = true;

                btnSave.Text = "Update";
            }

            if (mode == "vendor")
            {
                label8.Visible = false;
                txtRegional.Visible = false;

                btnCreateAcc.Visible = false;
            }
            else if (mode == "staff")
            {
                label8.Visible = true;
                txtRegional.Visible = true;

                btnCreateAcc.Visible = true;
            }
        }

        private bool isNumVCS(string inputNum)
        {
            Int64 dt = 0;
            return Int64.TryParse(inputNum, out dt);
        }

        private bool isValidEmail(string email)
        {
            try
            {
                var mail = new MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void MsPartner_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure want to close this form?", "Warning", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
                this.Activate();
            }
        }

        private void txtPartName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                foreach (DataGridViewRow row in DataGridView1.Rows)
                {
                    if (row.Cells[1].Value.ToString().ToUpper() == txtPartName.Text.ToUpper())
                    {
                        DataGridView1.CurrentCell = DataGridView1[1, row.Index];
                        loadPartner(DataGridView1.CurrentRow.Cells[0].Value.ToString());

                        state = "edit";
                        configForm();
                    }
                }
            }
        }

        private void rbVendor_Click(object sender, EventArgs e)
        {
            if (rbVendor.Checked)
            {
                mode = "vendor";

                loadDataGrid();
                loadAutoComplete();

                resetForm();
                state = "save";
                configForm();
            }
        }

        private void rbStaff_Click(object sender, EventArgs e)
        {
            if (rbStaff.Checked)
            {
                mode = "staff";

                loadDataGrid();
                loadAutoComplete();

                resetForm();
                state = "save";
                configForm();
            }
        }

        private void btnCreateAcc_Click(object sender, EventArgs e)
        {
            if (hidPartnerID.Text != "")
            {
                PopUpCreateAccount popUpCreateAccount = new PopUpCreateAccount(hidPartnerID.Text);
                //popUpCreateAccount.MdiParent = this.MdiParent;
                popUpCreateAccount.Show();
            }
            else
            {
                MessageBox.Show("No Partner Chosen !!");
            }
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }

        private void txtMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }
    }
}
