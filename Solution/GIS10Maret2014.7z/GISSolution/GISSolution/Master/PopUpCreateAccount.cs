﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using TCLibrary;

namespace GIS.Master
{
    public partial class PopUpCreateAccount : Form
    {
        string conString;
        string mode;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;

        string state;
        string localpartnerid;

        public PopUpCreateAccount()
        {
            InitializeComponent();
            mode = "popup";
        }

        public PopUpCreateAccount(string partnerid)
        {
            InitializeComponent();
            loadUser(partnerid);
            localpartnerid = partnerid;
            mode = "popup";
        }

        public PopUpCreateAccount(string partnerid, string flagmode)
        {
            InitializeComponent();
            mode = flagmode;
            cbAdmin.Visible = false;

            loadUser(partnerid);
            localpartnerid = partnerid;
        }

        private void loadUser(string partnerid)
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                cmd = new MySqlCommand();
                cmd.CommandText = "select userid, username, isadmin from msusers where partnerid = " + partnerid;
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();
                    hidUserID.Text = reader.GetInt32(0).ToString();
                    txtUserName.Text = reader.GetString(1);
                    cbAdmin.Checked = Convert.ToBoolean(reader.GetInt32(2));
                    state = "update";
                }
                else
                {
                    state = "new";
                }

                reader.Close();
                con.Close();

                configForm();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (validateForm())
            {
                if (state == "new")
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        int isadmin = 0;
                        if (cbAdmin.Checked) { isadmin = 1; }

                        con.Open();
                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into msusers (username, partnerid, password, isadmin, datein, userin) values ('" + txtUserName.Text + "', " + localpartnerid + ", '" + TCEncryption.Encrypt(txtPassword.Text) + "', " + isadmin.ToString() + ", now(), " + MySession.UserID + ")";
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Save New User !!");
                        this.Close();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
                else if (state == "update")
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        int isadmin = 0;
                        if (cbAdmin.Checked) { isadmin = 1; }

                        con.Open();
                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hsusers (username, partnerid, password, isadmin, datein, userin, dateup, userup) select username, partnerid, password, isadmin, datein, userin, now(), " + MySession.UserID + " from msusers where userid = " + hidUserID.Text + "; update msusers set password = '" + TCEncryption.Encrypt(txtPassword.Text) + "', isadmin = " + isadmin.ToString() + " where userid = " + hidUserID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Update User !!");
                        this.Close();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void configForm()
        {
            if (state == "new")
            {
                btnCreate.Text = "Create Account";
                txtUserName.Enabled = true;
            }
            else if (state == "update")
            {
                btnCreate.Text = "Update Account";
                txtUserName.Enabled = false;
            }
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("Please Fill User Name !!");
            }
            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Please Fill Password !!");
            }
            else
            {
                return true;
            }

            return false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (hidUserID.Text != "")
            {
                con.Open();
                cmd = new MySqlCommand();
                cmd.CommandText = "insert into hsusers (username, partnerid, password, isadmin, datein, userin, dateup, userup) select username, partnerid, password, isadmin, datein, userin, now(), " + MySession.UserID + " from msusers where userid = " + hidUserID.Text + "; delete from msusers where userid = " + hidUserID.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("Success Delete User !!");
                this.Close();
            }
        }
    }
}
