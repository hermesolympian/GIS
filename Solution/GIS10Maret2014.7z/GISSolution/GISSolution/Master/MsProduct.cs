﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace GIS.Master
{
    public partial class MsProduct : Form
    {
        string conString;
        List<string> listProdName;
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader reader;

        string state;

        public MsProduct()
        {
            InitializeComponent();

            loadCombo();
            loadDataGrid();
            loadAutoComplete();

            resetForm();
            state = "save";
            configForm();
        }

        private void loadCombo()
        {
            DataTable dt = new DataTable();
            DataRow dr = new DataTable().NewRow();

            dt.Columns.Add(new DataColumn("display", Type.GetType("System.String")));
            dt.Columns.Add(new DataColumn("value", Type.GetType("System.String")));

            dr = dt.NewRow();
            dr["display"] = "+";
            dr["value"] = "+";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["display"] = "-";
            dr["value"] = "-";
            dt.Rows.Add(dr);

            cmbSign.Items.Clear();

            cmbSign.DataSource = dt;
            cmbSign.DisplayMember = "display";
            cmbSign.ValueMember = "value";

            dt = new DataTable();
            dr = new DataTable().NewRow();

            dt.Columns.Add(new DataColumn("display", Type.GetType("System.String")));
            dt.Columns.Add(new DataColumn("value", Type.GetType("System.String")));

            dr = dt.NewRow();
            dr["display"] = "S";
            dr["value"] = "S";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["display"] = "A";
            dr["value"] = "A";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["display"] = "B";
            dr["value"] = "B";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["display"] = "C";
            dr["value"] = "C";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["display"] = "D";
            dr["value"] = "D";
            dt.Rows.Add(dr);

            cmbClass.Items.Clear();

            cmbClass.DataSource = dt;
            cmbClass.DisplayMember = "display";
            cmbClass.ValueMember = "value";
        }

        private void loadDataGrid()
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                listProdName = new List<string>();
                cmd = new MySqlCommand();
                cmd.CommandText = "SELECT  a.productid, productname, qty, returqty, hpp, note,        coalesce(MAX(CASE WHEN classid = 'S' THEN price ELSE NULL END),0) SPrice, coalesce(MAX(CASE WHEN classid = 'A' THEN price ELSE NULL END),0) APrice, coalesce(MAX(CASE WHEN classid = 'B' THEN price ELSE NULL END),0) BPrice, coalesce(MAX(CASE WHEN classid = 'C' THEN price ELSE NULL END),0) CPrice, coalesce(MAX(CASE WHEN classid = 'D' THEN price ELSE NULL END),0) DPrice from msproduct a inner join msproductprice b on a.productid = b.productid GROUP BY a.productid, productname, qty, returqty, hpp, note";
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                DataRow dr = new DataTable().NewRow();

                dt.Columns.Add(new DataColumn("productid", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("Product Name", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Quantity", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("Return Quantity", Type.GetType("System.Int32")));
                dt.Columns.Add(new DataColumn("HPP", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("Note", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("S Price", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("A Price", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("B Price", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("C Price", Type.GetType("System.String")));
                dt.Columns.Add(new DataColumn("D Price", Type.GetType("System.String")));

                while (reader.Read())
                {
                    dr = dt.NewRow();
                    dr["productid"] = reader.GetInt32(0);
                    dr["Product Name"] = reader.GetString(1);
                    dr["Quantity"] = reader.GetInt32(2);
                    dr["Return Quantity"] = reader.GetInt32(3);
                    dr["HPP"] = "Rp." + reader.GetDecimal(4).ToString();
                    dr["Note"] = reader.GetString(5);
                    dr["S Price"] = "Rp." + reader.GetDecimal(6).ToString();
                    dr["A Price"] = "Rp." + reader.GetDecimal(7).ToString();
                    dr["B Price"] = "Rp." + reader.GetDecimal(8).ToString();
                    dr["C Price"] = "Rp." + reader.GetDecimal(9).ToString();
                    dr["D Price"] = "Rp." + reader.GetDecimal(10).ToString();

                    dt.Rows.Add(dr);

                    listProdName.Add(reader.GetString(1));
                }
                DataGridView1.DataSource = dt;

                DataGridView1.Columns["productid"].Visible = false;
                DataGridView1.Columns["Note"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void loadAutoComplete()
        {
            string[] prodName = new string[listProdName.Count];
            var source = new AutoCompleteStringCollection();
            int i = 0;

            foreach (string temp in listProdName)
            {
                prodName[i] = temp;
                i++;
            }
            source.AddRange(prodName);

            txtProdName.AutoCompleteCustomSource = source;
            txtProdName.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtProdName.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            loadProduct(DataGridView1.CurrentRow.Cells[0].Value.ToString());

            state = "edit";
            configForm();
        }

        private void loadProduct(string productid)
        {
            conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
            con = new MySqlConnection(conString);

            try
            {
                con.Open();

                cmd = new MySqlCommand();
                cmd.CommandText = "SELECT  a.productid, productname, qty, returqty, hpp, note,        coalesce(MAX(CASE WHEN classid = 'S' THEN price ELSE NULL END),0) SPrice, coalesce(MAX(CASE WHEN classid = 'A' THEN price ELSE NULL END),0) APrice, coalesce(MAX(CASE WHEN classid = 'B' THEN price ELSE NULL END),0) BPrice, coalesce(MAX(CASE WHEN classid = 'C' THEN price ELSE NULL END),0) CPrice, coalesce(MAX(CASE WHEN classid = 'D' THEN price ELSE NULL END),0) DPrice from msproduct a inner join msproductprice b on a.productid = b.productid where a.productid = " + productid + " GROUP BY a.productid, productname, qty, returqty, hpp, note ";
                cmd.Connection = con;
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    hidProdID.Text = reader.GetInt32(0).ToString();
                    hidPrevQtyCPrice.Text = reader.GetInt32(2).ToString() + "!" + reader.GetInt32(3).ToString() + "!" + reader.GetDecimal(6).ToString() + "!" + reader.GetDecimal(7).ToString() + "!" + reader.GetDecimal(8).ToString() + "!" + reader.GetDecimal(9).ToString() + "!" + reader.GetDecimal(10).ToString();

                    txtProdName.Text = reader.GetString(1);
                    txtPrevQty.Text = reader.GetInt32(2).ToString();
                    txtSellPrice.Text = reader.GetDecimal(6).ToString();
                    txtNote.Text = reader.GetString(5);

                    cmbClass.SelectedIndex = 0;
                    cbRetur.Checked = false;
                }

                reader.Close();
                con.Close();
            }
            catch (MySqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (state == "save")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into msproduct (productname, qty, returqty, hpp, note, datein, userin) values ('" + txtProdName.Text + "', 0, 0, 0, '" + txtNote.Text + "', now(), " + MySession.UserID + "); SELECT LAST_INSERT_ID();";
                        cmd.Connection = con;
                        hidProdID.Text = cmd.ExecuteScalar().ToString();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into msproductprice (classid, productid, price, datein, userin) values ('" + cmbClass.SelectedValue + "', " + hidProdID.Text + ", " + txtSellPrice.Text.Replace(',', '.') + ", now(), " + MySession.UserID + ")";
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Save New Product !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else if (state == "edit")
            {
                state = "update";
                configForm();
            }
            else if (state == "update")
            {
                if (validateForm())
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();

                        int newQty = 0;
                        txtQty.Text = (txtQty.Text == "") ? "0" : txtQty.Text;
                        newQty = Convert.ToInt32(txtPrevQty.Text) + (Convert.ToInt32(cmbSign.SelectedValue + txtQty.Text));
                        string extra = (cbRetur.Checked) ? "returqty = " + newQty + ", " : "qty = " + newQty + ", ";

                        cmd.CommandText = "insert into hsproduct (productname, qty, returqty, hpp, note, datein, userin, dateup, userup) select productname, qty, returqty, hpp, note, datein, userin, now(), " + MySession.UserID + " from msproduct where productid = " + hidProdID.Text + ";update msproduct set productname = '" + txtProdName.Text + "', " + extra + "note = '" + txtNote.Text + "' where productid = " + hidProdID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "select productpriceid from msproductprice where productid = " + hidProdID.Text + " and classid = '" + cmbClass.SelectedValue + "'";
                        cmd.Connection = con;
                        reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            string[] temp = hidPrevQtyCPrice.Text.Split('!');
                            bool updateproductprice = false;
                            if (cmbClass.SelectedValue.ToString() == "S")
                            {
                                if (txtSellPrice.Text != temp[2])
                                {
                                    updateproductprice = true;
                                }
                            }
                            else if (cmbClass.SelectedValue.ToString() == "A")
                            {
                                if (txtSellPrice.Text != temp[3])
                                {
                                    updateproductprice = true;
                                }
                            }
                            else if (cmbClass.SelectedValue.ToString() == "B")
                            {
                                if (txtSellPrice.Text != temp[4])
                                {
                                    updateproductprice = true;
                                }
                            }
                            else if (cmbClass.SelectedValue.ToString() == "C")
                            {
                                if (txtSellPrice.Text != temp[5])
                                {
                                    updateproductprice = true;
                                }
                            }
                            else if (cmbClass.SelectedValue.ToString() == "D")
                            {
                                if (txtSellPrice.Text != temp[6])
                                {
                                    updateproductprice = true;
                                }
                            }

                            if (updateproductprice)
                            {
                                reader.Read();
                                cmd = new MySqlCommand();
                                cmd.CommandText = "insert into hsproductprice (classid, productid, price, datein, userin, dateup, userup) select classid, productid, price, datein, userin, now(), " + MySession.UserID + " from msproductprice where productpriceid = " + reader.GetInt32(0).ToString() + "; update msproductprice set price = " + txtSellPrice.Text.Replace(',', '.') + " where productpriceid = " + reader.GetInt32(0).ToString();

                                con.Close();
                                con.Open();

                                cmd.Connection = con;
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            cmd = new MySqlCommand();
                            cmd.CommandText = "insert into msproductprice (classid, productid, price, datein, userin) values ('" + cmbClass.SelectedValue + "', " + hidProdID.Text + ", " + txtSellPrice.Text.Replace(',', '.') + ", now(), " + MySession.UserID + ")";

                            con.Close();
                            con.Open();

                            cmd.Connection = con;
                            cmd.ExecuteNonQuery();
                        }

                        reader.Close();
                        con.Close();

                        MessageBox.Show("Success Update Product !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetForm();
            state = "save";
            configForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (hidProdID.Text != "")
            {
                if (MessageBox.Show("Are you sure want to delete this item?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    conString = ConfigurationManager.ConnectionStrings["localConString"].ConnectionString;
                    con = new MySqlConnection(conString);

                    try
                    {
                        con.Open();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hsproduct (productname, qty, returqty, hpp, note, datein, userin, dateup, userup) select productname, qty, returqty, hpp, note, datein, userin, now(), " + MySession.UserID + " from msproduct where productid = " + hidProdID.Text + "; delete from msproduct where productid = " + hidProdID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        cmd = new MySqlCommand();
                        cmd.CommandText = "insert into hsproductprice (classid, productid, price, datein, userin, dateup, userup) select classid, productid, price, datein, userin, now(), " + MySession.UserID + " from msproductprice where productid = " + hidProdID.Text + "; delete from msproductprice where productid = " + hidProdID.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        con.Close();

                        MessageBox.Show("Success Delete Product !!");

                        resetForm();
                        state = "save";
                        configForm();

                        loadDataGrid();
                    }
                    catch (MySqlException ex)
                    {
                        con.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No Product Chosen !!");
            }
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txtProdName.Text))
            {
                MessageBox.Show("Please Fill Product Name !!");
            }
            else if (string.IsNullOrEmpty(txtQty.Text))
            {
                MessageBox.Show("Please Fill Quantity !!");
            }
            else if (!isNumVCS(txtQty.Text) || (isNumVCS(txtQty.Text) && txtQty.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Quantity With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtSellPrice.Text))
            {
                MessageBox.Show("Please Fill Sell Price !!");
            }
            else if (!isDecimalVCS(txtSellPrice.Text) || (isDecimalVCS(txtSellPrice.Text) && txtSellPrice.Text.Contains('-')))
            {
                MessageBox.Show("Please Fill Sell Price With Numeric Value [0-9] !!");
            }
            else if (string.IsNullOrEmpty(txtNote.Text))
            {
                MessageBox.Show("Please Fill Note !!");
            }
            else
            {
                return true;
            }

            return false;
        }

        private void resetForm()
        {
            txtProdName.Text = "";
            txtPrevQty.Text = "0";
            txtQty.Text = "0";
            txtSellPrice.Text = "";
            txtNote.Text = "";

            hidProdID.Text = "";
            hidPrevQtyCPrice.Text = "";

            cmbSign.SelectedIndex = 0;
            cmbClass.SelectedIndex = 0;
            cbRetur.Checked = false;
        }

        private void configForm()
        {
            if (state == "save")
            {
                txtProdName.Enabled = true;
                txtQty.Enabled = false;
                txtSellPrice.Enabled = true;
                txtNote.Enabled = true;
                cmbSign.Enabled = false;
                cmbClass.Enabled = true;
                cbRetur.Enabled = false;

                btnSave.Text = "Save";
            }
            else if (state == "edit")
            {
                txtProdName.Enabled = false;
                txtQty.Enabled = false;
                txtSellPrice.Enabled = false;
                txtNote.Enabled = false;
                cmbSign.Enabled = false;
                cmbClass.Enabled = false;
                cbRetur.Enabled = false;

                btnSave.Text = "Edit";
            }
            else if (state == "update")
            {
                txtProdName.Enabled = true;
                txtQty.Enabled = true;
                txtSellPrice.Enabled = true;
                txtNote.Enabled = true;
                cmbSign.Enabled = true;
                cmbClass.Enabled = true;
                cbRetur.Enabled = true;

                btnSave.Text = "Update";
            }
        }

        private bool isNumVCS(string inputNum)
        {
            Int64 dt = 0;
            return Int64.TryParse(inputNum, out dt);
        }

        private bool isDecimalVCS(string inputNum)
        {
            Decimal dt = 0;
            return Decimal.TryParse(inputNum, out dt);
        }

        private void MsProduct_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure want to close this form?", "Warning", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
                this.Activate();
            }
        }

        private void txtProdName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                foreach (DataGridViewRow row in DataGridView1.Rows)
                {
                    if (row.Cells[1].Value.ToString().ToUpper() == txtProdName.Text.ToUpper())
                    {
                        DataGridView1.CurrentCell = DataGridView1[1, row.Index];
                        loadProduct(DataGridView1.CurrentRow.Cells[0].Value.ToString());

                        state = "edit";
                        configForm();
                    }
                }
            }
        }

        private void cbRetur_Click(object sender, EventArgs e)
        {
            string[] temp = hidPrevQtyCPrice.Text.Split('!');
            if (!cbRetur.Checked)
            {
                txtPrevQty.Text = temp[0];
            }
            else if (cbRetur.Checked)
            {
                txtPrevQty.Text = temp[1];
            }
        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (hidPrevQtyCPrice.Text != "")
            {
                string[] temp = hidPrevQtyCPrice.Text.Split('!');
                if (cmbClass.SelectedValue.ToString() == "S")
                {
                    txtSellPrice.Text = temp[2];
                }
                else if (cmbClass.SelectedValue.ToString() == "A")
                {
                    txtSellPrice.Text = temp[3];
                }
                else if (cmbClass.SelectedValue.ToString() == "B")
                {
                    txtSellPrice.Text = temp[4];
                }
                else if (cmbClass.SelectedValue.ToString() == "C")
                {
                    txtSellPrice.Text = temp[5];
                }
                else if (cmbClass.SelectedValue.ToString() == "D")
                {
                    txtSellPrice.Text = temp[6];
                }
            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }

        private void txtSellPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            const char Koma = (char)46;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete && e.KeyChar != Koma;
        }
    }
}
