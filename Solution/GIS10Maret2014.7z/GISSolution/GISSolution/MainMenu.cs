﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GIS.Master;

namespace GIS
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void assetsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MsAssets assets = new MsAssets();
            assets.MdiParent = this;
            assets.Location = new Point(FormPosition.XStartPos, FormPosition.YStartPos);
            assets.Show();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MsCustomer customer = new MsCustomer();
            customer.MdiParent = this;
            customer.Location = new Point(FormPosition.XStartPos, FormPosition.YStartPos);
            customer.Show();
        }

        private void partnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MsPartner partner = new MsPartner();
            partner.MdiParent = this;
            partner.Location = new Point(FormPosition.XStartPos, FormPosition.YStartPos);
            partner.Show();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MsProduct product = new MsProduct();
            product.MdiParent = this;
            product.Location = new Point(FormPosition.XStartPos, FormPosition.YStartPos);
            product.Show();
        }

        private void MainMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Login login = new Login();
            login.Show();
        }

        private void MainMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure want to logout?", "Warning", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
                this.Activate();
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void userManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PopUpCreateAccount createAccount = new PopUpCreateAccount(MySession.UserID, "mainmenu");
            createAccount.MdiParent = this;
            createAccount.Location = new Point(FormPosition.XStartPos, FormPosition.YStartPos);
            createAccount.Show();
        }
    }
}
