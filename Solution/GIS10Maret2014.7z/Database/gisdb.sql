-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2014 at 10:36 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gisdb`
--
CREATE DATABASE IF NOT EXISTS `gisdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `gisdb`;

-- --------------------------------------------------------

--
-- Table structure for table `hsassets`
--

CREATE TABLE IF NOT EXISTS `hsassets` (
  `AssetsID` int(11) NOT NULL AUTO_INCREMENT,
  `AssetsName` varchar(200) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Value` decimal(20,2) NOT NULL,
  `Note` varchar(250) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateUp` datetime DEFAULT NULL,
  `UserUp` int(11) DEFAULT NULL,
  PRIMARY KEY (`AssetsID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `hsassets`
--

INSERT INTO `hsassets` (`AssetsID`, `AssetsName`, `Qty`, `Value`, `Note`, `DateIn`, `UserIn`, `DateUp`, `UserUp`) VALUES
(2, 'Mobil', 5, '250000000.00', 'Mobil kantor buat para manager.', '2014-02-26 14:00:18', 7, '2014-02-26 14:08:14', 7),
(3, 'Mobil', 3, '250000000.00', 'Mobil kantor buat para manager.', '2014-02-26 14:00:18', 7, '2014-02-26 14:10:37', 7),
(4, 'Mobil', 3, '1500000000.25', 'Mobil kantor buat para manager.', '2014-02-26 14:00:18', 7, '2014-02-26 14:16:27', 7),
(5, 'Mobil', -3, '1500000000.25', 'Mobil kantor buat para manager.\r\nDibawa kabur semua, makanya minus.', '2014-02-26 14:00:18', 7, '2014-02-26 14:23:36', 7),
(6, 'Mouse', -10, '500000.50', 'Hilang semua ntah kemana.', '2014-02-26 14:19:52', 7, '2014-02-26 14:26:48', 7),
(7, 'Monitor', 25, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:14:13', 7),
(8, 'Monitor', -5, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:14:33', 7),
(9, 'Monitor', -5, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:14:40', 7),
(10, 'Monitor', 25, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:22:00', 7),
(11, 'Monitor', 25, '-25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:22:18', 7),
(12, 'Monitor', 25, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7, '2014-02-27 14:29:23', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hscustomer`
--

CREATE TABLE IF NOT EXISTS `hscustomer` (
  `CustomerID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(100) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `PlaceOfBirth` varchar(100) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateUp` datetime DEFAULT NULL,
  `UserUp` int(11) DEFAULT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `hscustomer`
--

INSERT INTO `hscustomer` (`CustomerID`, `CustomerName`, `Phone`, `Mobile`, `Email`, `Address`, `DateOfBirth`, `PlaceOfBirth`, `DateIn`, `UserIn`, `DateUp`, `UserUp`) VALUES
(5, 'Kevin Garnett', '0214505050', '0815707070', 'kg@email.com', 'Jl. Brooklyn Nets', '2014-02-25', 'NY', '2014-02-25 15:26:00', 7, '2014-02-25 15:26:47', 7),
(6, 'Yao Ming', '0214505050', '0815707070', 'kg@email.com', 'Jl. Brooklyn Nets', '2014-02-05', 'NY', '2014-02-25 15:26:00', 7, '2014-02-25 15:27:05', 7),
(7, 'Dirk Nowitzky', '0214505050', '081590908080', 'mavs@email.com', 'Jl, Dallas Cowboy 41', '2014-02-25', 'TX', '2014-02-25 16:01:37', 7, '2014-02-27 14:24:18', 7),
(8, 'Dirk Nowitzky', '0214505050', '-081590908080', 'mavs@email.com', 'Jl, Dallas Cowboy 41', '2014-02-25', 'TX', '2014-02-25 16:01:37', 7, '2014-02-27 14:24:26', 7),
(9, 'Dirk Nowitzky', '0214505050', '081590908080', 'mavs@email.com', 'Jl, Dallas Cowboy 41', '2014-02-25', 'TX', '2014-02-25 16:01:37', 7, '2014-02-27 14:25:38', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hspartner`
--

CREATE TABLE IF NOT EXISTS `hspartner` (
  `PartnerID` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerName` varchar(100) NOT NULL,
  `Regional` varchar(100) DEFAULT NULL,
  `Phone` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `PlaceOfBirth` varchar(100) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateUp` datetime DEFAULT NULL,
  `UserUp` int(11) DEFAULT NULL,
  PRIMARY KEY (`PartnerID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hspartner`
--

INSERT INTO `hspartner` (`PartnerID`, `PartnerName`, `Regional`, `Phone`, `Mobile`, `Email`, `Address`, `DateOfBirth`, `PlaceOfBirth`, `DateIn`, `UserIn`, `DateUp`, `UserUp`) VALUES
(2, 'Ultraman', NULL, '0214505050', '081590908080', 'ultra@web.com', 'Jl. Dunia Entah Berantah', '2014-02-24', 'Japan', '2014-02-26 16:48:44', 7, '2014-02-26 16:56:55', 7),
(3, 'Kamen Rider Kuga', 'Jakarta', '0214505050', '081590908080', 'kuga@jaring.com', 'Jl. Kurang Tau Juga Sih', '2014-02-06', 'Japan', '2014-02-26 16:51:29', 7, '2014-02-26 16:57:30', 7),
(4, 'Ultraman', NULL, '0214505050', '081590908080', 'ultra@web.com', 'Jl. Dunia Lain', '2014-02-05', 'Japan', '2014-02-26 16:48:44', 7, '2014-02-26 16:59:14', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hsproduct`
--

CREATE TABLE IF NOT EXISTS `hsproduct` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(200) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReturQty` int(11) NOT NULL,
  `HPP` decimal(20,2) NOT NULL,
  `Note` varchar(250) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateUp` datetime DEFAULT NULL,
  `UserUp` int(11) DEFAULT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `hsproduct`
--

INSERT INTO `hsproduct` (`ProductID`, `ProductName`, `Qty`, `ReturQty`, `HPP`, `Note`, `DateIn`, `UserIn`, `DateUp`, `UserUp`) VALUES
(15, 'Krim Oles', 0, 0, '0.00', 'Baru input.', '2014-02-28 14:01:58', 7, '2014-02-28 14:03:18', 7),
(16, 'Krim Oles', 10, 0, '0.00', 'Input qty +.', '2014-02-28 14:01:58', 7, '2014-02-28 14:05:44', 7),
(17, 'Krim Oles', 5, 0, '0.00', 'Input qty -.', '2014-02-28 14:01:58', 7, '2014-02-28 14:07:05', 7),
(18, 'Krim Oles', 5, 20, '0.00', 'Input retur qty +.', '2014-02-28 14:01:58', 7, '2014-02-28 14:07:18', 7),
(19, 'Krim Oles', 5, 10, '0.00', 'Input retur qty -.', '2014-02-28 14:01:58', 7, '2014-02-28 14:15:02', 7),
(20, 'Krim Oles', 5, 10, '0.00', 'Test bug update.', '2014-02-28 14:01:58', 7, '2014-02-28 14:15:40', 7),
(21, 'Krim Oles', 5, 10, '0.00', 'Update class S.', '2014-02-28 14:01:58', 7, '2014-02-28 14:17:10', 7),
(22, 'Krim Oles', 5, 10, '0.00', 'Insert class baru (D).', '2014-02-28 14:01:58', 7, '2014-02-28 14:17:57', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hsproductprice`
--

CREATE TABLE IF NOT EXISTS `hsproductprice` (
  `ProductPriceID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassID` varchar(5) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Price` decimal(20,2) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateUp` datetime NOT NULL,
  `UserUp` int(11) NOT NULL,
  PRIMARY KEY (`ProductPriceID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `hsproductprice`
--

INSERT INTO `hsproductprice` (`ProductPriceID`, `ClassID`, `ProductID`, `Price`, `DateIn`, `UserIn`, `DateUp`, `UserUp`) VALUES
(7, 'S', 5, '0.00', '2014-02-28 14:01:58', 7, '2014-02-28 14:15:40', 7),
(8, 'S', 5, '5000.00', '2014-02-28 14:01:58', 7, '2014-02-28 14:17:57', 7),
(9, 'D', 5, '10000.00', '2014-02-28 14:17:10', 7, '2014-02-28 14:17:57', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hsusers`
--

CREATE TABLE IF NOT EXISTS `hsusers` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `PartnerID` int(11) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `IsAdmin` int(11) NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserUp` int(11) NOT NULL,
  `DateUp` datetime NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hsusers`
--

INSERT INTO `hsusers` (`UserID`, `UserName`, `PartnerID`, `Password`, `IsAdmin`, `UserIn`, `DateIn`, `UserUp`, `DateUp`) VALUES
(3, 'TEST', 2, 'MExRfseGNJ4=', 1, 7, '2014-02-28 16:23:53', 7, '2014-02-28 16:34:15');

-- --------------------------------------------------------

--
-- Table structure for table `msassets`
--

CREATE TABLE IF NOT EXISTS `msassets` (
  `AssetsID` int(11) NOT NULL AUTO_INCREMENT,
  `AssetsName` varchar(200) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Value` decimal(20,2) NOT NULL,
  `Note` varchar(250) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  PRIMARY KEY (`AssetsID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `msassets`
--

INSERT INTO `msassets` (`AssetsID`, `AssetsName`, `Qty`, `Value`, `Note`, `DateIn`, `UserIn`) VALUES
(3, 'Monitor', 25, '25000000.00', 'Baru beli dari pasar.', '2014-02-26 14:25:16', 7),
(4, 'Keyboard', 25, '2500000.00', 'Beli bareng monitor.', '2014-02-26 14:29:31', 7);

-- --------------------------------------------------------

--
-- Table structure for table `mscustomer`
--

CREATE TABLE IF NOT EXISTS `mscustomer` (
  `CustomerID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(100) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `PlaceOfBirth` varchar(100) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `mscustomer`
--

INSERT INTO `mscustomer` (`CustomerID`, `CustomerName`, `Phone`, `Mobile`, `Email`, `Address`, `DateOfBirth`, `PlaceOfBirth`, `DateIn`, `UserIn`) VALUES
(7, 'Dirk Nowitzky', '+62214505050', '081590908080', 'mavs@email.com', 'Jl, Dallas Cowboy 41', '2014-02-25', 'TX', '2014-02-25 16:01:37', 7),
(8, 'Steve Francis', '0214505050', '081590908080', 'sf@email.com', 'Jl. Rockets', '2014-02-26', 'TX', '2014-02-26 14:46:18', 7);

-- --------------------------------------------------------

--
-- Table structure for table `mspartner`
--

CREATE TABLE IF NOT EXISTS `mspartner` (
  `PartnerID` int(11) NOT NULL AUTO_INCREMENT,
  `PartnerName` varchar(100) NOT NULL,
  `Regional` varchar(100) DEFAULT NULL,
  `Phone` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `PlaceOfBirth` varchar(100) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  PRIMARY KEY (`PartnerID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mspartner`
--

INSERT INTO `mspartner` (`PartnerID`, `PartnerName`, `Regional`, `Phone`, `Mobile`, `Email`, `Address`, `DateOfBirth`, `PlaceOfBirth`, `DateIn`, `UserIn`) VALUES
(2, 'Kamen Rider Kuga', 'Sinabung', '0214505050', '081590908080', 'kuga@jaring.com', 'Jl. Kurang Tau Juga Sih', '2014-02-06', 'Japan', '2014-02-26 16:51:29', 7),
(3, 'Zeo Ranger', NULL, '0214505050', '081580809090', 'zranger@megazord.com', 'Jl. Boulevard of Broken Dream', '2014-02-26', 'USA', '2014-02-26 16:58:33', 7);

-- --------------------------------------------------------

--
-- Table structure for table `msproduct`
--

CREATE TABLE IF NOT EXISTS `msproduct` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(200) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReturQty` int(11) NOT NULL,
  `HPP` decimal(20,2) NOT NULL,
  `Note` varchar(250) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `msproductprice`
--

CREATE TABLE IF NOT EXISTS `msproductprice` (
  `ProductPriceID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassID` varchar(5) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Price` decimal(20,2) NOT NULL,
  `DateIn` datetime NOT NULL,
  `UserIn` int(11) NOT NULL,
  PRIMARY KEY (`ProductPriceID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `msusers`
--

CREATE TABLE IF NOT EXISTS `msusers` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `PartnerID` int(11) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `IsAdmin` int(11) NOT NULL,
  `UserIn` int(11) NOT NULL,
  `DateIn` datetime NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `msusers`
--

INSERT INTO `msusers` (`UserID`, `UserName`, `PartnerID`, `Password`, `IsAdmin`, `UserIn`, `DateIn`) VALUES
(1, 'TEST', 2, 'YDQOMBusENUAQ89GD0JveQ==', 0, 7, '2014-02-28 16:23:53');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
